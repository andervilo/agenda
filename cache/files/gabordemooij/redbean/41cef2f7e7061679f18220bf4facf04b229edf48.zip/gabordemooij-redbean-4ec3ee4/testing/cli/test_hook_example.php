<?php

/**
 *
 * Here you can add logic to be executed during the bootstrapping
 * of RedUNIT.
 *
 * You can define/use the following variables:
 *
 * $hookPath -> add 1 additional path which will be searched for unit tests
 * $extraTestsFromHook -> array with additional test packs (will be executed if you pass 'all' argument to CLI runner)
 *
 *
 */